﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pAtividade8
{
    public partial class Exercicio1 : Form
    {
        public Exercicio1()
        {
            InitializeComponent();
        }

		private void btnVerificar_Click(object sender, EventArgs e)
		{
			int[] vetor = new int[20];
			string auxiliar = "";
			
			for (var i = 0; i < vetor.Length; i++)
			{
				auxiliar = Interaction.InputBox("Entre com número:" + (i + 1).ToString(),
				"Entrada de Dados");

				if (!int.TryParse(auxiliar, out vetor[i]))
				{
					MessageBox.Show("Número inválido!");
					i--;
				}
			}
			auxiliar = "";
			for (var i = vetor.Length - 1; i >= 0; i--)
				auxiliar += "\n" + vetor[i];
			MessageBox.Show(auxiliar);
		}
    }
}
