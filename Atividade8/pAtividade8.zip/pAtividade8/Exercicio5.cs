﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade8
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            //Ana, André, Débora, Fátima, João, Janete, Otávio, Marcelo, Pedro, Thais
            
            List<string> nomeVetor3 = new List<string>()
            {
                "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"
            };
            //remover um determinado nome:
            nomeVetor3.Remove("Otávio");

            //imprimir
            string aux = "";
            foreach (string nome in nomeVetor3)
            {
                aux += nome + "\n";
            }
            MessageBox.Show(aux);

        }
    }
}
