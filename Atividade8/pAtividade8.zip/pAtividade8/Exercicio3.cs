﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pAtividade8
{
    public partial class Exercicio3 : Form
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void btnFaturamento_Click(object sender, EventArgs e)
        {
            //criando as variáveis
            int[] quantidade = new int[10]; //vetor para receber a quantidade vendidae de cada item
            double[] valor = new double[10]; //vetor para receber o preço unitário de cada item

            double total = 0;//total faturado

            //Laço para ler cada um dos produtos
            for (int venda=0; venda<quantidade.Length; venda++)
            {
                var leitura = Interaction.InputBox("Quantidade Vendida:", $"Produto #{venda + 1}");//primeiro parametro é o texto e o segundo é o titulo
                
                //essa quantidade é inválida?
                if (!int.TryParse(leitura, out quantidade[venda]))
                {
                    MessageBox.Show("Valor inválido!");
                    venda--;//decrementa
                    continue;//voltar e tentar ler novamente
                }

                leitura = Interaction.InputBox("Valor Unitário:", $"Produto #{venda + 1}");
                if (!double.TryParse(leitura, out valor[venda]))
                {
                    MessageBox.Show("Valor inválido!", "Atenção!");
                    venda--;
                    continue;
                }
                total += quantidade[venda] * valor[venda];
            }
            //MessageBox.Show(total.ToString("N2"));
            //MessageBox.Show("Total Faturado = " + total);
            MessageBox.Show($"Total Faturado: {total:N2}");

        }
    }
}
