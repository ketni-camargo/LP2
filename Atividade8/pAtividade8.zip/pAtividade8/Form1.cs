﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio1 objFrm2 = new Exercicio1();//criar objeto
            objFrm2.MdiParent = this;
            objFrm2.WindowState = FormWindowState.Maximized; //vai abrir maximizado
            objFrm2.Show();
        }
        private void exercício2ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Exercicio2 objFrm3 = new Exercicio2();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio3 objFrm4 = new Exercicio3();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio4 objFrm5 = new Exercicio4();
            objFrm5.MdiParent = this;
            objFrm5.WindowState = FormWindowState.Maximized;
            objFrm5.Show();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio5 objFrm6 = new Exercicio5();
            objFrm6.MdiParent = this;
            objFrm6.WindowState = FormWindowState.Maximized;
            objFrm6.Show();
        }

        private void exercício6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio6 objFrm7 = new Exercicio6();
            objFrm7.MdiParent = this;
            objFrm7.WindowState = FormWindowState.Maximized;
            objFrm7.Show();
        }

        private void exercícioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio7 objFrm8 = new Exercicio7();
            objFrm8.MdiParent = this;
            objFrm8.WindowState = FormWindowState.Maximized;
            objFrm8.Show();
        }

    }
}

