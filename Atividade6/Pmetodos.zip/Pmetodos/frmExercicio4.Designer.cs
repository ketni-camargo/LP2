﻿
namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnQuantidadeNumerico = new System.Windows.Forms.Button();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnCaracterAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(148, 77);
            this.rchtxtTexto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(608, 179);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            // 
            // btnQuantidadeNumerico
            // 
            this.btnQuantidadeNumerico.BackColor = System.Drawing.Color.SeaGreen;
            this.btnQuantidadeNumerico.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuantidadeNumerico.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnQuantidadeNumerico.Location = new System.Drawing.Point(74, 303);
            this.btnQuantidadeNumerico.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnQuantidadeNumerico.Name = "btnQuantidadeNumerico";
            this.btnQuantidadeNumerico.Size = new System.Drawing.Size(215, 83);
            this.btnQuantidadeNumerico.TabIndex = 1;
            this.btnQuantidadeNumerico.Text = "Quantidade de Caracteres Numéricos";
            this.btnQuantidadeNumerico.UseVisualStyleBackColor = false;
            this.btnQuantidadeNumerico.Click += new System.EventHandler(this.btnQuantidadeNumerico_Click);
            // 
            // btnBranco
            // 
            this.btnBranco.BackColor = System.Drawing.Color.SeaGreen;
            this.btnBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBranco.Location = new System.Drawing.Point(345, 303);
            this.btnBranco.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(216, 83);
            this.btnBranco.TabIndex = 2;
            this.btnBranco.Text = "Primeiro Caracter Branco";
            this.btnBranco.UseVisualStyleBackColor = false;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnCaracterAlfa
            // 
            this.btnCaracterAlfa.BackColor = System.Drawing.Color.SeaGreen;
            this.btnCaracterAlfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracterAlfa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCaracterAlfa.Location = new System.Drawing.Point(603, 307);
            this.btnCaracterAlfa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCaracterAlfa.Name = "btnCaracterAlfa";
            this.btnCaracterAlfa.Size = new System.Drawing.Size(218, 79);
            this.btnCaracterAlfa.TabIndex = 3;
            this.btnCaracterAlfa.Text = "Quantidade Caracteres Alfabéticos";
            this.btnCaracterAlfa.UseVisualStyleBackColor = false;
            this.btnCaracterAlfa.Click += new System.EventHandler(this.btnCaracterAlfa_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(1200, 623);
            this.Controls.Add(this.btnCaracterAlfa);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.btnQuantidadeNumerico);
            this.Controls.Add(this.rchtxtTexto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.Button btnQuantidadeNumerico;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnCaracterAlfa;
    }
}