﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQuantidadeNumerico_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            for (int i = 0; i < rchtxtTexto.TextLength; i++)
            {
                if (Char.IsNumber(rchtxtTexto.Text[i]))
                {
                    quantidade++;
                }
            }
            MessageBox.Show(quantidade.ToString());
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            if (rchtxtTexto.TextLength > 0) //será executado se existir texto
            {
                while (!char.IsWhiteSpace(rchtxtTexto.Text[posicao]))
                {
                    if (posicao == rchtxtTexto.TextLength - 1)
                    {
                        posicao = 0;
                        break;
                    }
                    posicao++;
                }
                MessageBox.Show(posicao.ToString());
            }
            else
            {
                MessageBox.Show("Não há texto");
            }
        }

        private void btnCaracterAlfa_Click(object sender, EventArgs e)
        {
            int quantidade = 0;

            foreach (char letra in rchtxtTexto.Text)
            {
                if (char.IsLetter(letra))
                {
                    quantidade++;
                }
            }
            MessageBox.Show(quantidade.ToString());

        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }
    }
}
