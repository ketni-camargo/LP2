﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random numAleatorio = new Random();
            int numero1, numero2;

            if(int.TryParse (txtNumero1.Text, out numero1) && int.TryParse(txtNumero2.Text, out numero2))
            {
                int sorteio;
                if(numero1 < numero2)
                {
                    sorteio = numAleatorio.Next(numero1, numero2);
                }
              
                else
                {
                    sorteio = numAleatorio.Next(numero2, numero1);
                }
                MessageBox.Show(sorteio.ToString());
            }
        }
    }
}
