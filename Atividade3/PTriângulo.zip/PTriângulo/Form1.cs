﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Text = " ";
            txtValorB.Text = " ";
            txtValorC.Text = " ";
            txtValorA.Focus();

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtValorA.Text, out ladoA) && double.TryParse(txtValorB.Text, out ladoB) && double.TryParse(txtValorC.Text, out ladoC))    
            {
                    if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) &&
                       ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) &&
                       ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
                    {
                    if (ladoA == ladoB && ladoB == ladoC)
                        MessageBox.Show("Triângulo Equilátero!");
                    else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                        MessageBox.Show("Triângulo Isósceles!");
                    
                    else
                        MessageBox.Show("Triângulo Escaleno!");
                    }
                    else
                        MessageBox.Show("Valores não pertencem aos lados de um triângulo!");
            }
            else
                MessageBox.Show("Dados inválidos!");
        }
    }
}
