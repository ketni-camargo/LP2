﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            // - atribui valores para o objeto
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioPorHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaNaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasDeFalta.Text);

            //get - imprime os valores do objeto
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado +
                      "\n" + "Matrícula: " + objHorista.Matricula + "\n" +
                      "Tempo Trabalho: " + objHorista.TempoTrabalho().ToString()
                      + "\n" + "Salário: " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
