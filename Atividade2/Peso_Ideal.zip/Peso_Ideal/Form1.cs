﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Peso_Ideal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Text = " ";
            maskedTextBox2.Text = " ";

            maskedTextBox1.Focus();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            double altura = 0;
            double pesoAtual = 0;
            double pesoIdeal = 0;
            
            if (Double.TryParse(maskedTextBox1.Text, out altura) && (Double.TryParse(maskedTextBox2.Text, out pesoAtual)))
            
            {
                if (rbtnFeminino.Checked)
                {
                    pesoIdeal = (62.1 * altura) - 44.7;
                    pesoIdeal = Math.Round(pesoIdeal, 2);
                }
                else
                {
                    pesoIdeal = (72.7 * altura) - 58;
                    pesoIdeal = Math.Round(pesoIdeal, 2);
                }
            
                if (pesoAtual == pesoIdeal)
                    { MessageBox.Show("Peso Ideal : " + pesoIdeal + "\n" + "Você está com o peso ideal"); }
                else if (pesoAtual < pesoIdeal)
                    { MessageBox.Show("Peso Ideal: " + pesoIdeal + "\n" + "Coma bastante massas ou doces"); }
                else
                    { MessageBox.Show("Peso Ideal : " + pesoIdeal + "\n" + "Regime Obrigatório"); }

            }
                
            else
                MessageBox.Show("Dados inválidos");
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
