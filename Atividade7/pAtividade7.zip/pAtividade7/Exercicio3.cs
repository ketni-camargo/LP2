﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class Exercicio3 : Form
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;

            texto = texto.Replace(" ", "");

            texto = texto.ToUpper();

            string textoInvertido = new string(texto.Reverse().ToArray());

            if (texto == textoInvertido)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtTexto.Text = "";
        }
    }
}
