﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio1 objFrm2 = new Exercicio1();//criar objeto
            objFrm2.MdiParent = this;
            objFrm2.WindowState = FormWindowState.Maximized; //vai abrir maximizado
            objFrm2.Show();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio2 objFrm3 = new Exercicio2();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized; 
            objFrm3.Show();
        }

        private void form3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio3 objFrm4 = new Exercicio3();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized; 
            objFrm4.Show();
        }

        private void form44ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercicio4 objFrm5 = new Exercicio4();
            objFrm5.MdiParent = this;
            objFrm5.WindowState = FormWindowState.Maximized; 
            objFrm5.Show();
        }
    }
}
