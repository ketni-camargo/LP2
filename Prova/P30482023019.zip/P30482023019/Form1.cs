﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P30482023019
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int mes = 9;
            int semana = 4;

            double[,] vendas = new double[mes, semana];
            double[] vendasMes = new double[mes];
            double totalMeses = 0;



            for (int i = 0; i < mes; i++)
            {
                vendasMes[i] = 0;
                for (int j = 0; j < semana; j++)
                {
                    var totalSemana = Interaction.InputBox($"Entre com o total vendido na semana #{j + 1}", $"Mês {i + 1}");
                    if (!double.TryParse(totalSemana, out vendas[i, j]))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                        continue;
                    }
                    vendasMes[i] += vendas[i, j];
                    totalMeses += vendasMes[i];

                }

            }


            for (int i = 0; i < mes; i++)
            {
                for (int j = 0; j < semana; j++)
                {
                    listResultado.Items.Add("Total do Mês:" + (i + 1) + "   Semana: " + (j + 1) + "  " + vendas[i, j].ToString("C2"));
                }
                listResultado.Items.Add(">>Total Mês: " + vendasMes[i].ToString("C2"));
                listResultado.Items.Add("..............................................................");
            }
            listResultado.Items.Add("Total Geral: " + totalMeses.ToString("C2"));
        }
    }
}
