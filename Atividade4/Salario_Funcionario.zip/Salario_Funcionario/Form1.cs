﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salario_Funcionario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void mkdbxAliquotaINSS_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mkdbxAliquotaIRPF_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mkdbxSalarioFamilia_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mkdbxSalarioLiquido_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mkdbxDescontoINSS_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblMensagem.Visible = true;

            double descontoINSS = 0;
            double descontoIR = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double numeroFilhos = 0;

            if ((txtNome.Text == "") || (txtNome.Text.Length < 10))
                MessageBox.Show("Nome inválido!");
            else if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
            {
                //calculo do INSS
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 0.11 * salarioBruto;
                }
                else
                {
                    txtAliquotaINSS.Text = "308.17";
                    descontoINSS = 308.17;
                }
                //mostro o desconto do INSS
                mskbxDescontoINSS.Text = descontoINSS.ToString("N2");


                //calculo do IR
                if (salarioBruto <= 1257.12)
                {
                    txtAliquotaIRPF.Text = "Isento";

                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliquotaIRPF.Text = "15%";
                    descontoIR = 0.15 * salarioBruto;
                }
                else
                {
                    txtAliquotaIRPF.Text = "27.5%";
                    descontoIR = 0.275 * salarioBruto;
                }
                mskbxDescontoIRPF.Text = descontoIR.ToString("N2");


                //calculo do salário família

                if (double.TryParse(cbxNumeroFilhos.Text, out numeroFilhos))
                {

                    if (salarioBruto <= 435.52)
                    {
                        salarioFamilia = 22.33 * numeroFilhos;
                    }
                    else if (salarioBruto <= 654.61)
                    {
                        salarioFamilia = 15.74 * numeroFilhos;
                    }
                    else
                        salarioFamilia = 0;

                    mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");




                    //salario liquido

                    salarioLiquido = salarioBruto - descontoINSS - descontoIR + salarioFamilia;
                    mskbxSalarioLiquido.Text = salarioLiquido.ToString("N2");

                    //monta a mensagem no label
                    lblMensagem.Text = "Os descontos do salário ";
                    if (rbtnFeminino.Checked)
                        lblMensagem.Text = lblMensagem.Text + "da Sr.ª " + txtNome.Text;
                    else
                        lblMensagem.Text = lblMensagem.Text + "do Sr. " + txtNome.Text;

                    lblMensagem.Text = lblMensagem.Text + " que é ";

                    if (ckbxCasado.Checked) //é casado
                        lblMensagem.Text = lblMensagem.Text + "casado(a) e que tem " + cbxNumeroFilhos.Text + " filho(s) são: ";
                    else
                        lblMensagem.Text = lblMensagem.Text + "solteiro(a) e que tem " + cbxNumeroFilhos.Text + " filho(s) são: ";
                }
                else
                    MessageBox.Show("Selecione a quantidade de filhos!");
            }
            else
                MessageBox.Show("Salário Bruto inválido!");
        
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            mskbxSalarioBruto.Text = "";
            cbxNumeroFilhos.Text = "";
            ckbxCasado.Checked = false;
            lblMensagem.Text = "";
            txtAliquotaINSS.Text = "";
            txtAliquotaIRPF.Text = "";
            mskbxSalarioFamilia.Text = "";
            mskbxSalarioLiquido.Text = "";
            mskbxDescontoINSS.Text = "";
            mskbxDescontoIRPF.Text = "";
            txtNome.Focus();

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
